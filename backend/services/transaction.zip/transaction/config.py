RABBITMQ_HOST = 'host.docker.internal'
QUEUE_NAME = 'transaction_logs'